import './App.css';
import SignIn from './Containers/SignIn'
import FakeApi from './Components/FakeApi/FakeApi'

function App() {
  return (
    <div className="App">
    <SignIn/>
    <FakeApi/>
    </div>
  );
}

export default App;
